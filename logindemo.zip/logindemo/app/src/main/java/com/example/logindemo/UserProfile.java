package com.example.logindemo;

public class UserProfile {

    public String birthdate;
    public String email;
    public String username;
    public String surname;
    public String gjaku;
    public String qyteti;
    public String celular;



    public UserProfile(String birthdate, String email, String username, String surname, String gjaku, String qyteti, String celular) {
        this.birthdate = birthdate;
        this.email = email;
        this.username = username;
        this.surname = surname;
        this.gjaku= gjaku;
        this.qyteti= qyteti;
        this.celular =celular;
    }
}
